package com.galaxyt.normae.test.web;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test1")
public class TestController {

    @PreAuthorize("hasAnyAuthority('aaaa')")
    @GetMapping("aaa")
    public String aaa() {

        String name = SecurityContextHolder.getContext().getAuthentication().getName();

        System.out.println(name);

        return "aaaa";
    }


    @PreAuthorize("hasAnyRole('ADMINISTRATOR')")
    @GetMapping("bbb/{a}/{b}")
    public String bbb() {
        return "bbb";
    }



}
