package com.galaxyt.normae.test;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

@Slf4j
@EnableResourceServer
@SpringBootApplication(scanBasePackages = "com.galaxyt")
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class TestApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestApplication.class, args);
        log.info("============================ Test * System startup completed ===================================================");
    }


}
