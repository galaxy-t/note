package com.galaxyt.normae.uaa;

import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

/**
 * 用户认证中心
 *
 * @author zhouqi
 * @version v1.0.0
 * @date 2020/5/20 9:59
 * @Description Modification History:
 * Date                 Author          Version          Description
 * ---------------------------------------------------------------------------------*
 * 2020/5/20 9:59     zhouqi          v1.0.0           Created
 */
@Slf4j
@EnableResourceServer
@SpringBootApplication(scanBasePackages = "com.galaxyt")
@MapperScan(basePackages = "com.galaxyt.normae.uaa.dao")
public class UaaApplication {


    public static void main(String[] args) {
        SpringApplication.run(UaaApplication.class, args);
        log.info("============================ UAA * System startup completed ===================================================");
    }

}
