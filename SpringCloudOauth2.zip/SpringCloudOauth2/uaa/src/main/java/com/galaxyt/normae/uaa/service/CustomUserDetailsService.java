package com.galaxyt.normae.uaa.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.galaxyt.normae.uaa.dao.AuthorityDao;
import com.galaxyt.normae.uaa.dao.RoleDao;
import com.galaxyt.normae.uaa.dao.UserDao;
import com.galaxyt.normae.uaa.enums.Deleted;
import com.galaxyt.normae.uaa.enums.Disabled;
import com.galaxyt.normae.uaa.pojo.po.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 自定义的认证用户获取服务类
 *
 * @author zhouqi
 * @date 2020/5/18 17:09
 * @version v1.0.0
 * @Description
 *
 * Modification History:
 * Date                 Author          Version          Description
---------------------------------------------------------------------------------*
 * 2020/5/18 17:09     zhouqi          v1.0.0           Created
 *
 */
@Component("customUserDetailsService")
public class CustomUserDetailsService implements UserDetailsService {


    @Autowired
    private UserDao userDao;

    @Autowired
    private RoleDao roleDao;

    @Autowired
    private AuthorityDao authorityDao;


    /**
     * 初始化系统管理员帐号
     */
    @Value("${system.administrator.username}")
    private String systemAdministratorUsername;


    /**
     * 系统默认的用户角色
     * 不论其是否拥有其它角色该角色都会带上
     */
    private static final String ROLE_DEFAULT = "ROLE_DEFAULT";


    /**
     * 根据用户名获取认证用户信息
     *
     * @param username
     * @return
     * @throws UsernameNotFoundException
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {


        User user = this.userDao.selectOne(new QueryWrapper<User>()
                .eq("username", username));

        //未查询到用户
        if (user == null) {
            throw new UsernameNotFoundException(String.format("用户[%s]不存在", username));
        }

        //用户状态未启用 TODO
        if (user.getDisabled() == Disabled.TRUE) {

        }

        //查询当前登录用户下未被禁用且未被删除的角色列表
        //数据库中存储的角色 MARK 应为 ROLE_ 作为前缀
        List<String> roles = this.roleDao.selectByUserId(user.getId(), Disabled.FALSE, Deleted.FALSE);

        //查询当前登录用户下未被禁用且未被删除的权限列表
        List<String> authorities = null;

        if (username.equals(this.systemAdministratorUsername)) {
            authorities = this.authorityDao.selectAll();
        } else {
            authorities = this.authorityDao.selectByUserId(user.getId(), Disabled.FALSE, Deleted.FALSE);
        }

        //用户已被授予的角色权限
        List<GrantedAuthority> grantedAuthorities = Stream.concat(roles.parallelStream(), authorities.parallelStream()).distinct().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
        //总是为用户授权一个默认的角色
        grantedAuthorities.add(new SimpleGrantedAuthority(ROLE_DEFAULT));

        //创建一个用于认证的用户对象并返回, 其中包括: 用户名 密码 角色/权限
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), grantedAuthorities);

    }


}
